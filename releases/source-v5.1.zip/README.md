# 上帝模式 Lite v5.1 · 使用说明

> root 免框架 + LSPosed 模块双模式界面工具。v5 重点：**全局唯一悬浮球、只能手动开关且重开应用不恢复**、**可主动退出并杀死后台（不自动启动）**、**眼睛+红色斜杠新图标**、**列表/瀑布流两种应用布局**、内存优化。
> APK：`GodModeLite-5.1.apk`（包名 `com.dsh.godmodelite`，versionCode 6 / 5.1，minSdk 21 / targetSdk 28，约 229 KB，内置测试签名）

---

## v5.1 更新点（LSPosed 诊断与生效修复）

1. **模块生效可验证**：模块在目标进程 `onResume/onPostResume` 时向主应用写「心跳」（60 秒节流）；主界面状态卡显示 `LSPosed：模块已生效 · 心跳 时间 (包名)`。没有心跳就说明模块还没真正注入。
2. **root 读取 LSPosed**：「更多… → LSPosed 诊断（root 读取）」用 root 只读探测：LSPosed 安装目录、`zygisk_lsposed/module.prop`、`lspd` 进程、`/data/adb/lspd/config` 里是否写入本模块、config 中的应用包名、LSPosed 日志里的 `GodModeLite` 记录；同时显示模块心跳与模块日志，快速判断「模块没启用 / 没勾作用域 / 目标应用没重启 / 框架没运行」。
3. **重启不生效的修复**：
   - `handleLoadPackage` 不再要求 `isFirstApplication`，界面跑在 `:ui` 等子进程的应用也能注入；
   - 增加 `Activity.onPostResume` hook（onResume 之后再补一次应用），提升重启后首次打开的命中率；
   - 模块把成功拉到的规则**缓存到目标应用私有 SharedPreferences**，重启后主应用还没被拉起（provider 不可用）时按缓存规则继续生效；
   - 心跳/日志通过导出 Provider 回传主应用（失败静默，不影响目标应用）。
4. 其余功能同 v5.0（唯一悬浮球只能手动开关、主动退出后台、列表/瀑布流、自动备份保留 2 份、眼睛+红色斜杠图标）。

## v5.0 更新点（沿用）

1. **全局唯一悬浮球**：无障碍悬浮球存在时，LSPosed 模块不会再加第二个球；任何界面最多只有一个悬浮图标。
2. **只能手动显示**：默认关闭；只有主界面手动打开「悬浮球」开关才显示；**重新打开 App 也不会自动恢复**；关闭后任何界面都不会出现（即使权限都在）。
3. **主动退出后台**：新增「更多… → 退出并关闭后台（停止服务）」：关闭悬浮球、解绑无障碍服务、结束进程；之后**不会自动启动**，需要手动打开 App。Android 7 以下会引导先手动关无障碍。
4. **新应用图标**：眼睛 + 红色禁止斜杠（深色圆角底），含自适应图标与 5 组密度 PNG。
5. **列表 / 瀑布流布局**：「更多… → 布局」切换：列表（单列，图标+徽章）或瀑布流（双列圆角卡片，已配置应用仍置顶）。
6. **内存优化**：规则统计不再拷贝列表（`ConfigStore.stats()` / `packageStats()`）、应用列表 15 秒缓存、图标 LruCache + 后台线程 + `onTrimMemory` 清理、图层选择单画布自绘、无障碍节点即用即回收。

## 二、两种模式

| | root 免框架模式 | LSPosed 模块模式（真删） |
|---|---|---|
| 前提 | root 或手动开无障碍 | root + LSPosed |
| 效果 | 悬浮窗遮挡 + 拦截点击 | 目标进程内 `setVisibility(GONE)` 真正删除 |
| 悬浮球 | 全局唯一球（手动开关） | 不重复加球（已有无障碍球时自动隐藏），按需在目标进程内提供 |

> root 不能跨进程删 View；真删必须 LSPosed 模块；两种模式规则互通。

## 三、安装与 root 一键配置

1. 安装 APK → 打开。
2. 「一键配置（root）」自动执行：
   ```sh
   settings put secure enabled_accessibility_services "<原列表>:com.dsh.godmodelite/com.dsh.godmodelite.a11y.BlockerService"
   settings put secure accessibility_enabled 1
   appops set com.dsh.godmodelite SYSTEM_ALERT_WINDOW allow
   ```
3. 无 root：手动开无障碍 + 「显示在其他应用上层」权限。
4. 「布局边界」开关（root）：`setprop debug.layout` 全局显示控件边框，重启自动关闭。

## 四、悬浮球（唯一 / 手动）

- 主界面打开「悬浮球」开关 → 出现**唯一**悬浮球；拖动摇动记住位置；单击进入图层选择；长按菜单。
- 关闭开关 / 关闭 App / 退出后台后，任何界面都不显示；重开 App 时开关是关的，需要手动再开。
- 「悬浮球样式」：5 种样式 × 3 尺寸 × 3 档透明度。
- 若同时启用 LSPosed 模块：无障碍悬浮球存在时模块不再加球，避免出现两个。

## 五、图层选择

点悬浮球 / 主界面「图层选择」/ 规则页「图层选择」→ 所有可见控件画彩色边框（6 色按层级、标签、最多 300 个），点选后「遮挡（绿）/ 真删（红）/ 取消（灰）」。

## 六、应用列表：列表 / 瀑布流

「更多… → 布局：列表/瀑布流」切换：
- **列表**：单列，40dp 图标 + 应用名 + 包名 + 「遮挡 N」「真删 M」徽章；
- **瀑布流**：双列圆角卡片，每张卡片图标 + 名称 + 规则数 + 徽章；
- 两种布局都支持智能排序（已配置置顶分组）/ 名称 / 规则数、筛选、搜索。

## 七、退出并关闭后台（v5）

「更多… → 退出并关闭后台（停止服务）」：
1. 关闭悬浮球、清理窗口；
2. Android 7+ 调 `AccessibilityService.disableSelf()` 解绑无障碍服务；Android 6 及以下引导到系统设置手动关闭；
3. `finishAndRemoveTask()` 并结束进程；
4. 系统**不会自动启动**本应用（没有开机广播 / 前台服务，无障碍服务已解绑）。

## 八、自动备份（v4 起）

- 打开「启用屏蔽」自动备份到 `Android/data/com.dsh.godmodelite/files/backup/`，保留最近 **2 份**，新备份按时间覆盖旧的；App 当天首次启动也会补一份。
- 主界面右上「自动备份：N 份 ›」可立即备份 / 恢复最近一份 / 开关。

## 九、LSPosed 模块模式（真删）

> v5.1：启用模块并勾选作用域后，**必须强制停止目标应用**（或重启手机）才会重新加载模块；打开目标应用后回本应用看状态卡是否出现「模块已生效 · 心跳」，没有就点「更多 → LSPosed 诊断」。

1. root 下装 LSPosed → 重启 → 管理器。
2. 「模块」勾选「上帝模式 Lite」→ 作用域勾选目标应用（不要系统应用）。
3. 强制停止目标应用 → 重开。
4. App 里加「真删」规则，元素真正消失。日志搜 `GodModeLite`。

## 十、兼容性 / 限制

- Android 5.0 ~ 14；Android 13/14 侧载需先「允许受限设置」。
- root 模式为遮挡 + 拦截点击；真删需 LSPosed。
- WebView/Flutter/Unity 自绘、小于 4px、不可见节点可能识别不到。
- 规则 Provider 为跨进程同步而 exported（无权限），App 无 INTERNET 权限。

## 十一、构建 / 文件

```sh
bash toolchain/build.sh app dist/GodModeLite-5.0.apk
bash toolchain/verify.sh dist/GodModeLite-5.0.apk
bash toolchain/test/run_tests.sh
```

```
GodModeLite-5.0.apk   安装包
使用说明.md            本文件
原软件分析.md          原版逆向分析
验收报告.md            构建/验收记录
图标预览.png           新图标 512px 预览
源码.zip               完整工程
```
