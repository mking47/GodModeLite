package com.dsh.godmodelite.a11y;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dsh.godmodelite.core.ConfigStore;
import com.dsh.godmodelite.core.Rule;

import java.util.List;
import java.util.UUID;

/**
 * 拾取悬浮层：全屏半透明覆盖层，让用户点击要遮挡的界面元素。
 *
 * 流程：
 * 1. 全屏 0x11000000 半透明层 + 顶部提示条 + 底部「取消」按钮；
 * 2. 点击 ACTION_UP → NodeFinder.findNodeAt 找节点；
 * 3. 找不到 Toast「没识别到元素」；找到后显示绿色高亮框 + 底部确认卡片（保存 / 重选 / 取消）；
 * 4. 点「保存」构造 Rule → ConfigStore.addRule → 回调 Listener（由 BlockerService 停止拾取、立即刷蒙版）。
 *
 * 所有方法都在主线程调用（悬浮窗操作只能在主线程）。
 */
public class PickerOverlay {

    /** 拾取结果回调（由 BlockerService 实现） */
    public interface Listener {
        /** 用户保存了一条规则（此时拾取层已关闭） */
        void onPickerSaved(Rule rule);

        /** 用户取消拾取（此时拾取层已关闭） */
        void onPickerCancelled();
    }

    private static final String TAG = "GodModePicker";

    /** 拾取层背景：很淡的黑色，能看出进入了拾取模式，又不影响看清下面的界面 */
    private static final int COLOR_SCRIM = 0x11000000;
    /** 顶部提示条背景 */
    private static final int COLOR_HINT_BG = 0xCC000000;
    /** 顶部提示文字颜色 */
    private static final int COLOR_HINT_TEXT = 0xFFFFFFFF;
    /** 确认卡片背景 */
    private static final int COLOR_CARD_BG = 0xF2FFFFFF;
    /** 确认卡片文字颜色 */
    private static final int COLOR_CARD_TEXT = 0xFF222222;
    /** 高亮框填充色（半透明绿） */
    private static final int COLOR_HIGHLIGHT_FILL = 0x3300FF00;
    /** 高亮框描边色 */
    private static final int COLOR_HIGHLIGHT_STROKE = 0xFF00FF00;

    private final AccessibilityService service;
    private final WindowManager windowManager;
    private final Listener listener;

    /** 用于把屏幕坐标换算成拾取层内部坐标 */
    private final int[] rootLocation = new int[2];

    private FrameLayout rootView;
    private View highlightView;
    private LinearLayout confirmCard;
    private Button cancelButton;

    /** 进入拾取时指定的目标包名（AppDetail 传入），保存时会优先用当前前台包名 */
    private String targetPkg;
    /** 当前前台包名 / Activity 类名（随窗口事件更新） */
    private String currentPkg;
    private String currentActivity;

    private boolean showing;
    /** 是否正在显示确认卡片（此时忽略普通点击，只响应卡片按钮） */
    private boolean confirming;
    private Rule pendingRule;
    /** 实际成功添加拾取层时使用的窗口类型（不同 ROM 触摸支持不一致，会做一次降级重试） */
    private int pickOverlayType;

    public PickerOverlay(AccessibilityService service, WindowManager windowManager, Listener listener) {
        this.service = service;
        this.windowManager = windowManager;
        this.listener = listener;
    }

    /** 是否正在拾取 */
    public boolean isShowing() {
        return showing;
    }

    /**
     * 开始拾取。
     *
     * @param targetPkg 目标应用包名（从规则页进入时带过来），可为 null
     */
    public void start(String targetPkg) {
        // 重复调用时先清掉旧界面
        stop();
        PickerOverlay.this.targetPkg = targetPkg;
        if (windowManager == null) {
            toast("无法显示拾取层（窗口服务不可用）");
            return;
        }

        FrameLayout root = new PickerRootView(service);
        root.setBackgroundColor(COLOR_SCRIM);

        // 顶部提示条
        TextView hint = new TextView(service);
        hint.setText("点击要遮挡的元素（可点取消退出）");
        hint.setTextColor(COLOR_HINT_TEXT);
        hint.setTextSize(14f);
        hint.setGravity(Gravity.CENTER);
        hint.setBackgroundColor(COLOR_HINT_BG);
        hint.setPadding(dp(12), dp(10), dp(12), dp(10));
        FrameLayout.LayoutParams hintParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        hintParams.gravity = Gravity.TOP;
        root.addView(hint, hintParams);

        // 底部取消按钮
        Button cancel = new Button(service);
        cancel.setText("取消");
        cancel.setAllCaps(false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelPick();
            }
        });
        FrameLayout.LayoutParams cancelParams = new FrameLayout.LayoutParams(dp(120), dp(44));
        cancelParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        cancelParams.bottomMargin = dp(28);
        root.addView(cancel, cancelParams);
        cancelButton = cancel;

        // 1) 首选无障碍专用的 TYPE_ACCESSIBILITY_OVERLAY（无需悬浮窗权限）
        int primaryType = BlockerService.overlayWindowType();
        boolean added = addPickerWindow(root, primaryType);
        if (!added) {
            // 2) 兜底：部分 ROM 对无障碍 overlay 的触摸支持不一致，换一种悬浮窗类型再试一次
            int fallbackType = fallbackOverlayType(primaryType);
            if (fallbackType != 0) {
                added = addPickerWindow(root, fallbackType);
            }
        }
        if (!added) {
            toast("无法显示拾取层（悬浮窗可能被系统限制）");
            cancelButton = null;
            return;
        }
        rootView = root;
        showing = true;
    }

    /** 关闭拾取层，移除所有窗口与临时状态（可重复调用） */
    public void stop() {
        showing = false;
        confirming = false;
        pendingRule = null;
        // 清掉跟随窗口的状态，避免下次复用时残留上一个应用的包名/Activity
        currentPkg = null;
        currentActivity = null;
        pickOverlayType = 0;
        if (rootView != null && windowManager != null) {
            try {
                windowManager.removeView(rootView);
            } catch (Throwable t) {
                // 窗口可能已经不在，忽略
            }
        }
        rootView = null;
        highlightView = null;
        confirmCard = null;
        cancelButton = null;
    }

    /**
     * 前台窗口变化时通知拾取层：更新当前包名 / Activity。
     * 拾取期间切换页面不退出拾取，只更新目标信息；已选中的节点可能已失效，所以收起卡片。
     */
    public void setCurrentWindow(String pkg, String activity) {
        currentPkg = pkg;
        currentActivity = activity;
        if (showing && confirming) {
            clearConfirm();
        }
    }

    // ==================== 点击与拾取 ====================

    /** 处理全屏层上的点击（坐标为屏幕绝对坐标） */
    private void handleTap(float rawX, float rawY) {
        if (!showing || confirming) {
            return;
        }
        AccessibilityNodeInfo node;
        try {
            node = NodeFinder.findNodeAt(service, (int) rawX, (int) rawY);
        } catch (Throwable t) {
            node = null;
        }
        if (node == null) {
            toast("没识别到元素");
            return;
        }
        Rule rule = buildRule(node);
        if (rule == null) {
            toast("没识别到元素");
            return;
        }
        pendingRule = rule;
        showHighlight(node);
        showConfirmCard(rule);
    }

    /** 保存规则：写入 ConfigStore，关闭拾取层，回调 service 立即刷蒙版 */
    private void savePick() {
        final Rule rule = pendingRule;
        if (rule == null) {
            return;
        }
        // 保存时以「当前窗口包名」为准（拾取期间可能切换了页面）
        if (currentPkg != null && currentPkg.length() > 0) {
            rule.pkg = currentPkg;
        } else if (rule.pkg == null || rule.pkg.length() == 0) {
            rule.pkg = targetPkg;
        }
        if (rule.id == null) {
            rule.id = UUID.randomUUID().toString();
        }
        if (rule.created <= 0) {
            rule.created = System.currentTimeMillis();
        }
        rule.enabled = true;
        if (rule.pkg == null || rule.pkg.length() == 0) {
            toast("无法确定目标应用，保存失败");
            return;
        }
        try {
            ConfigStore.addRule(rule);
        } catch (Throwable t) {
            Log.w(TAG, "保存规则失败", t);
            toast("保存失败：" + t);
            return;
        }
        pendingRule = null;
        confirming = false;
        toast("已保存规则");
        // 先关闭拾取层，再通知 service 立即上蒙版
        stop();
        if (listener != null) {
            listener.onPickerSaved(rule);
        }
    }

    /** 取消拾取 */
    private void cancelPick() {
        stop();
        if (listener != null) {
            listener.onPickerCancelled();
        }
    }

    // ==================== 根据节点构造规则 ====================

    /** 把选中节点转成一条规则（此时还未保存） */
    private Rule buildRule(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        Rule rule = new Rule();
        rule.id = UUID.randomUUID().toString();
        rule.pkg = (currentPkg != null && currentPkg.length() > 0) ? currentPkg : targetPkg;
        rule.activity = currentActivity;
        rule.viewId = safeViewId(node);
        rule.cls = safeClassName(node);
        String text = safeText(node);
        rule.text = (text != null && text.length() > 0) ? text : null;
        Rect rect = new Rect();
        try {
            node.getBoundsInScreen(rect);
        } catch (Throwable t) {
            rect.setEmpty();
        }
        rule.l = rect.left;
        rule.t = rect.top;
        rule.r = rect.right;
        rule.b = rect.bottom;
        rule.path = pathForNode(node);
        rule.enabled = true;
        rule.created = System.currentTimeMillis();
        return rule;
    }

    /** 计算节点路径：优先用当前活动窗口根节点，失败再按窗口 id 找根节点 */
    private String pathForNode(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        AccessibilityNodeInfo root = null;
        try {
            root = service.getRootInActiveWindow();
        } catch (Throwable t) {
            root = null;
        }
        if (root == null) {
            root = rootForWindow(node);
        }
        if (root == null) {
            return null;
        }
        try {
            return NodeFinder.pathOf(root, node);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 按节点所在窗口 id 找到窗口根节点（兼容多窗口场景） */
    private AccessibilityNodeInfo rootForWindow(AccessibilityNodeInfo node) {
        if (node == null) {
            return null;
        }
        int windowId = -1;
        try {
            windowId = node.getWindowId();
        } catch (Throwable t) {
            windowId = -1;
        }
        if (windowId < 0) {
            return null;
        }
        try {
            List<AccessibilityWindowInfo> windows = service.getWindows();
            if (windows == null) {
                return null;
            }
            for (int i = 0; i < windows.size(); i++) {
                AccessibilityWindowInfo window = windows.get(i);
                if (window == null) {
                    continue;
                }
                // AccessibilityWindowInfo 用 getId() 表示窗口 id
                if (window.getId() == windowId) {
                    return window.getRoot();
                }
            }
        } catch (Throwable t) {
            return null;
        }
        return null;
    }

    // ==================== 高亮框与确认卡片 ====================

    /** 在选中节点位置画绿色高亮框 */
    private void showHighlight(AccessibilityNodeInfo node) {
        removeHighlight();
        if (rootView == null || node == null) {
            return;
        }
        Rect rect = new Rect();
        try {
            node.getBoundsInScreen(rect);
        } catch (Throwable t) {
            return;
        }
        if (rect.width() <= 0 || rect.height() <= 0) {
            return;
        }
        // 屏幕坐标 → 拾取层内部坐标
        rootView.getLocationOnScreen(rootLocation);
        int left = rect.left - rootLocation[0];
        int top = rect.top - rootLocation[1];

        View view = new View(service);
        GradientDrawable background = new GradientDrawable();
        background.setColor(COLOR_HIGHLIGHT_FILL);
        background.setStroke(dp(3), COLOR_HIGHLIGHT_STROKE);
        view.setBackground(background);
        view.setClickable(false);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(rect.width(), rect.height());
        params.leftMargin = left;
        params.topMargin = top;
        try {
            rootView.addView(view, params);
        } catch (Throwable t) {
            return;
        }
        highlightView = view;
    }

    /** 底部确认卡片：规则描述 + 保存 / 重选 / 取消 */
    private void showConfirmCard(Rule rule) {
        removeConfirmCard();
        if (rootView == null || rule == null) {
            return;
        }
        LinearLayout card = new LinearLayout(service);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable background = new GradientDrawable();
        background.setColor(COLOR_CARD_BG);
        background.setCornerRadius(dp(10));
        card.setBackground(background);
        card.setPadding(dp(14), dp(12), dp(14), dp(10));

        TextView title = new TextView(service);
        title.setText("将遮挡：");
        title.setTextColor(COLOR_CARD_TEXT);
        title.setTextSize(12f);

        TextView desc = new TextView(service);
        desc.setText(describeSafely(rule));
        desc.setTextColor(COLOR_CARD_TEXT);
        desc.setTextSize(15f);
        desc.setPadding(0, dp(2), 0, dp(8));

        card.addView(title);
        card.addView(desc);

        LinearLayout buttonRow = new LinearLayout(service);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);

        Button saveButton = createCardButton("保存");
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePick();
            }
        });
        Button reselectButton = createCardButton("重选");
        reselectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearConfirm();
            }
        });
        Button cancelButtonInCard = createCardButton("取消");
        cancelButtonInCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelPick();
            }
        });

        LinearLayout.LayoutParams firstParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        LinearLayout.LayoutParams secondParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        secondParams.leftMargin = dp(6);
        LinearLayout.LayoutParams thirdParams = new LinearLayout.LayoutParams(0, dp(42), 1f);
        thirdParams.leftMargin = dp(6);
        buttonRow.addView(saveButton, firstParams);
        buttonRow.addView(reselectButton, secondParams);
        buttonRow.addView(cancelButtonInCard, thirdParams);
        card.addView(buttonRow);

        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
        cardParams.gravity = Gravity.BOTTOM;
        cardParams.leftMargin = dp(12);
        cardParams.rightMargin = dp(12);
        cardParams.bottomMargin = dp(12);
        try {
            rootView.addView(card, cardParams);
        } catch (Throwable t) {
            return;
        }
        confirmCard = card;
        confirming = true;
        // 卡片本身有取消按钮，隐藏底部那个，避免两个按钮重叠
        if (cancelButton != null) {
            cancelButton.setVisibility(View.GONE);
        }
    }

    /** 收起确认卡片（重选 / 窗口变化时调用），回到“点击选元素”状态 */
    private void clearConfirm() {
        confirming = false;
        pendingRule = null;
        removeConfirmCard();
        removeHighlight();
        if (cancelButton != null && showing) {
            cancelButton.setVisibility(View.VISIBLE);
        }
    }

    private void removeConfirmCard() {
        if (confirmCard != null && rootView != null) {
            try {
                rootView.removeView(confirmCard);
            } catch (Throwable t) {
                // 忽略
            }
        }
        confirmCard = null;
    }

    private void removeHighlight() {
        if (highlightView != null && rootView != null) {
            try {
                rootView.removeView(highlightView);
            } catch (Throwable t) {
                // 忽略
            }
        }
        highlightView = null;
    }

    // ==================== 窗口参数与小工具 ====================

    /** 用指定窗口类型尝试添加拾取层；成功返回 true 并记录实际使用的类型 */
    private boolean addPickerWindow(FrameLayout root, int overlayType) {
        WindowManager.LayoutParams params = createPickerParams(overlayType);
        try {
            windowManager.addView(root, params);
            pickOverlayType = overlayType;
            return true;
        } catch (Throwable t) {
            // 悬浮窗被限制 / token 非法 / 该 ROM 不认这种窗口类型
            Log.w(TAG, "添加拾取层失败，type=" + overlayType, t);
            return false;
        }
    }

    /**
     * 备用悬浮窗类型：主类型 addView 失败时尝试一次；返回 0 表示没有可用的备用类型。
     * - API 26+：TYPE_APPLICATION_OVERLAY（常量值 2038，API 26 才有，编译用的是 API 23 的
     *   android.jar，所以这里直接写数值避免编译不过），需要「显示在其他应用上层」权限；
     * - API 21-25：TYPE_SYSTEM_ALERT（2002），同样需要悬浮窗权限，没权限时 addView 会失败。
     */
    private int fallbackOverlayType(int failedType) {
        if (Build.VERSION.SDK_INT >= 26) {
            final int typeApplicationOverlay = 2038;
            if (failedType != typeApplicationOverlay && canDrawOverlays()) {
                return typeApplicationOverlay;
            }
            return 0;
        }
        if (failedType != WindowManager.LayoutParams.TYPE_SYSTEM_ALERT) {
            return WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        }
        return 0;
    }

    /** 是否有「显示在其他应用上层」权限（API 23 才有 canDrawOverlays，更低版本交给 addView 试） */
    private boolean canDrawOverlays() {
        if (Build.VERSION.SDK_INT < 23) {
            return true;
        }
        try {
            return Settings.canDrawOverlays(service);
        } catch (Throwable t) {
            return false;
        }
    }

    /** 拾取层窗口参数：全屏、绝对定位、不获取焦点、可接收触摸 */
    private WindowManager.LayoutParams createPickerParams(int overlayType) {
        WindowManager.LayoutParams params = new WindowManager.LayoutParams();
        params.type = overlayType;
        params.format = PixelFormat.TRANSLUCENT;
        // 不获取焦点（不弹输入法）；不加 FLAG_NOT_TOUCHABLE（拾取层要收触摸）
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 0;
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;
        try {
            params.setTitle("gm-picker");
        } catch (Throwable t) {
            // 老系统没有 setTitle 也不影响功能
        }
        return params;
    }

    private Button createCardButton(String text) {
        Button button = new Button(service);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(13f);
        button.setPadding(dp(4), 0, dp(4), 0);
        return button;
    }

    private int dp(int value) {
        float density = service.getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    private void toast(String message) {
        try {
            Toast.makeText(service, message, Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            // Toast 失败不影响功能
        }
    }

    private String describeSafely(Rule rule) {
        if (rule == null) {
            return "元素";
        }
        try {
            String text = rule.describe();
            if (text != null && text.length() > 0) {
                return text;
            }
        } catch (Throwable t) {
            // 走兜底
        }
        if (rule.text != null && rule.text.length() > 0) {
            return rule.text;
        }
        if (rule.viewId != null && rule.viewId.length() > 0) {
            int index = rule.viewId.indexOf('/');
            if (index >= 0 && index + 1 < rule.viewId.length()) {
                return rule.viewId.substring(index + 1);
            }
            return rule.viewId;
        }
        if (rule.cls != null && rule.cls.length() > 0) {
            int index = rule.cls.lastIndexOf('.');
            if (index >= 0 && index + 1 < rule.cls.length()) {
                return rule.cls.substring(index + 1);
            }
            return rule.cls;
        }
        return "元素";
    }

    private static String safeViewId(AccessibilityNodeInfo node) {
        try {
            return node.getViewIdResourceName();
        } catch (Throwable t) {
            return null;
        }
    }

    private static String safeClassName(AccessibilityNodeInfo node) {
        try {
            CharSequence cs = node.getClassName();
            return cs == null ? null : cs.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    private static String safeText(AccessibilityNodeInfo node) {
        try {
            CharSequence cs = node.getText();
            return cs == null ? null : cs.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * 拾取层根布局：自己拦截触摸事件。
     * 子控件（按钮等）会先消费点击，其余位置的 ACTION_UP 才会走到这里。
     */
    private final class PickerRootView extends FrameLayout {

        PickerRootView(Context context) {
            super(context);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event == null) {
                return false;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                handleTap(event.getRawX(), event.getRawY());
            }
            // 返回 true 表示消费事件：拾取时不要把点击透传给目标应用
            return true;
        }
    }
}
