# 上帝模式 Lite v3.0 · 使用说明

> root 免框架 + LSPosed 模块双模式界面工具。v3 新增：悬浮球 5 种样式/尺寸/透明度、关闭 App 即隐藏悬浮球、信息更详细、应用列表排序筛选与已配置置顶、独立「使用说明书」页、图层选择界面更清晰、内存优化。
> APK：`GodModeLite-3.0.apk`（包名 `com.dsh.godmodelite`，versionCode 3 / 3.0，minSdk 21 / targetSdk 28，内置测试签名，约 97 KB）

---

## 一、两种模式

| | root 免框架模式（默认） | LSPosed 模块模式（真删） |
|---|---|---|
| 前提 | 有 root（自动配置）或手动开无障碍 | root + LSPosed 框架 |
| 原理 | 无障碍读节点 + 悬浮窗遮挡/拦点击 | Xposed hook 目标进程 `Activity.onResume`，`setVisibility(GONE)` **真正删除** |
| 悬浮球 | 全局悬浮球（无障碍 overlay） | 目标应用内每页一个悬浮球（进程内） |
| 图层选择 | 全屏自绘所有节点矩形 | 进程内自绘 decorView 所有 View 矩形 |
| 规则 | 同一条规则 `mode=遮挡/真删` | `mode=真删` 时真正生效 |

> Android 进程隔离决定「普通 App（即使有 root）不能在别人进程删 View」，真删必须 LSPosed；root 模式依然可用，两种模式规则互通。

## 二、安装与 root 一键配置

1. 安装 APK → 打开「上帝模式 Lite」。
2. 点 **「一键配置（root）」**，授权后自动执行：
   ```sh
   settings put secure enabled_accessibility_services "<原列表>:com.dsh.godmodelite/com.dsh.godmodelite.a11y.BlockerService"
   settings put secure accessibility_enabled 1
   appops set com.dsh.godmodelite SYSTEM_ALERT_WINDOW allow
   ```
3. 无 root：点「打开无障碍设置」手动开启，并给「显示在其他应用上层」权限。
4. **「系统布局边界（root）」** 开关：`setprop debug.layout true/false`，全局让系统绘制所有控件边框（重启自动关闭）。

## 三、悬浮球（本轮重点优化）

- 开启后屏幕出现悬浮球，**长按菜单**：打开上帝模式 Lite / 关闭悬浮球 / 隐藏悬浮球 / 取消。
- **单击**进入图层选择；**拖动**移动并记住位置。
- **自定义样式**：主界面「悬浮球样式」按钮 →
  - 样式：眼睛 / 圆点 / 盾牌 / 文字「隐」/ 禁止斜杠（5 种，纯矢量绘制，不占图片内存）
  - 尺寸：小 40dp / 中 48dp / 大 56dp
  - 透明度：低 150 / 中 200 / 高 235
  - 保存后立即生效（服务在线时实时刷新；模块球随规则同步）。
- **关闭即隐藏**：按返回键 / 最近任务划掉 App 后，悬浮球从其它界面消失（只隐藏本次运行，不写配置）；下次打开 App 且开关为「开」时自动恢复。按 Home 键不会隐藏。

## 四、图层选择（看见所有图层，界面更清晰）

1. 点悬浮球 / 主界面「图层选择」/ 规则页「图层选择」。
2. 覆盖层把所有可见控件画成彩色矩形（6 色按层级，1.5dp 边框，最多 300 个），有文字/ID 的元素带小标签；顶部显示「共 N 个图层 · 当前包名」。
3. 点选元素 → 3dp 绿框 + 外发光高亮 → 底部卡片：
   - 标题：元素文字 / viewId 末段；副标题：类名 · 坐标(左,上,宽×高)
   - **「遮挡」**（绿色实底）：白色蒙版盖住 + 拦截点击
   - **「真删」**（红色实底）：LSPosed 模块启用后真正 GONE，未启用时退化为遮挡
   - **「取消」**（深灰）
   - 按钮 52dp 高 / 16sp 粗体，深色高对比卡片。
4. 保存后立即生效，悬浮球恢复。

## 五、LSPosed 模块模式（真删 View）

1. root 下安装 LSPosed，重启，打开 LSPosed 管理器。
2. 「模块」→ 勾选 **上帝模式 Lite**（本 APK 同时是模块）。
3. 进入模块 →「作用域」→ 勾选目标应用（**不要勾系统应用**）→ 保存。
4. 强制停止 / 重启目标应用 → 生效。
5. App 里给该应用加规则并选「真删」；元素会真正消失。
6. 调试：LSPosed 管理器 → 日志 → 搜 `GodModeLite`。

## 六、应用列表：排序 / 筛选 / 已配置置顶

- **排序**按钮：智能排序（有规则的置顶 + 分组标题「已配置的应用（N）」/「其他应用（M）」）/ 按名称 / 按规则数（多→少）。
- **筛选**按钮：全部应用 / 仅有规则的应用。
- 搜索 + 排序 + 筛选可叠加。
- 每行显示应用图标、名称、包名、「遮挡 N」（绿）「真删 M」（红）徽章。

## 七、主界面信息（更详细）

状态卡 5 行：root 状态、无障碍服务（已连接/未连接）、规则统计（共 N · 遮挡 A · 真删 B）、悬浮球（显示中/隐藏 · 样式）、LSPosed 是否安装。规则页每行显示 mode 标签、viewId、类名、创建时间、坐标。

## 八、使用说明书页

主界面 →「使用说明书」→ 独立深色页面（7 节：两种模式、安装配置、悬浮球、图层选择、LSPosed 步骤、备份恢复、常见问题），root 命令以命令块展示。

## 九、备份 / 恢复

- 「备份规则」导出 JSON；「恢复规则」可导入本作 JSON，也可直接导入**原版「上帝模式」的 `.gzip`（实际 ZIP）备份**（自动解析 manifest.json，忽略 webp）。
- 规则 mode（遮挡/真删）随备份保存；旧备份无 mode 默认遮挡。

## 十、内存与性能（v3 优化）

- 图层选择改为**单个自绘 View**（onDraw 画全部矩形/标签），不再每个元素创建一个 View；上限 300（模块 200）。
- 无障碍节点遍历：子节点用完立即 recycle，最多访问 3000 节点，不长期持有节点树。
- 应用列表图标 `LruCache`（48 个）+ 后台加载，行复用；不在 `getView` 里查 PackageManager。
- 悬浮球纯几何绘制，无 Bitmap / 无静态 Context；服务/页面销毁时释放 Handler、窗口与列表引用。

## 十一、兼容性 / 限制

- Android 5.0 ~ Android 14；Android 13/14 侧载需先「允许受限设置」再开无障碍。
- 识别不到：WebView/Flutter/Unity 自绘、`isVisibleToUser=false`、小于 4px 的节点。
- 同时开无障碍球与模块球会看到两个球：可关主界面「悬浮球」开关（模块球仍在目标应用内）。
- 规则 Provider 为跨进程同步而 exported（无权限），本机应用理论上可读写规则；App 无 INTERNET 权限。
- 模块模式需要 LSPosed，系统应用不要加作用域。

## 十二、构建 / 文件

```sh
bash toolchain/build.sh app dist/GodModeLite-3.0.apk
bash toolchain/verify.sh dist/GodModeLite-3.0.apk
bash toolchain/test/run_tests.sh
```

```
GodModeLite-3.0.apk   安装包（v1+v2+v3 签名）
使用说明.md            本文件
原软件分析.md          原版逆向分析
验收报告.md            构建/验收记录
源码.zip               完整工程
```
